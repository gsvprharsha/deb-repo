/* Version information for exifprobe                                  */
/* @(#) $Id: version.h,v 1.17 2005/07/24 23:07:57 alex Exp $ */

char *Copyright = "Copyright (C) 2005 Duane H. Hesser, (C) 2011-2015 Hubert Figuiere";
char *Program_version = "2.1.0";
#define PATCHLEVEL    0
