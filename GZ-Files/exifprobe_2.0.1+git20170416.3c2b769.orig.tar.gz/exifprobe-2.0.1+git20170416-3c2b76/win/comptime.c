char *Comptime = __DATE__ " " __TIME__;
