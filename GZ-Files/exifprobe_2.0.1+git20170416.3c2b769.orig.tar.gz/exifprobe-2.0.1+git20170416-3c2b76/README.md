
This is a “fork” of exifprobe, a tool to probe Exif and other digital
camera RAW files.

Based on the 2.0.1 tarball as found in Debian.

Current maintainer: Hubert Figuière

Original maintainer: Duane H. Hesser

See file LICENSE.EXIFPROBE for the license
(basically a 3 clause BSD).

SECURITY NOTE
=============

This software hasn't been reviewed for security. Don't run it as
root. Beware running it on untrusted source data.